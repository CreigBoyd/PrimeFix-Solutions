<?php
/**
 * Configuration file for mailers and endpoints.
 * Credentials should be set via environment variables on your web server.
 * NEVER commit actual SMTP passwords to version control.
 */

return [
    // Your SMTP provider's details.
    'smtp_host'       => getenv('SMTP_HOST') ?: 'smtp.gmail.com',
    'smtp_user'       => getenv('SMTP_USER') ?: 'CreigB1@gmail.com',
    'smtp_pass'       => getenv('SMTP_PASS') ?: 'jbey xkbl omzz pwts',
    'smtp_port'       => (int) (getenv('SMTP_PORT') ?: 587),
    'smtp_secure'     => getenv('SMTP_SECURE') ?: 'tls', // 'tls' or 'ssl'

    // What recipients see as the "From" address.
    'from_email'      => getenv('SMTP_FROM_EMAIL') ?: 'CreigB1@gmail.com',
    'from_name'       => getenv('SMTP_FROM_NAME') ?: 'PrimeFix Solutions Website',

    // Where estimate requests, reviews, and newsletter signups get delivered.
    'notify_to_email' => getenv('NOTIFY_TO_EMAIL') ?: 'CreigB1@gmail.com',

    // Restrict CORS to your real domain(s) in production.
    'allowed_origin'  => getenv('ALLOWED_ORIGIN') ?: '*',
];